//Archivo Wine.model.h

//Pegar o crear archivo Wine.model.h

#pragma once   // Evita incluir este archivo más de una vez en el proyecto

// ===========================================================
// ====== Ajustes del Scaler (normalización de entradas) =====
// ===========================================================
// NUM_FEATURES: cantidad de características químicas del vino.
//   → corresponde a len(X.columns) en el script de Python.
const byte NUM_FEATURES = 11;

// wine_mean: medias de cada característica, usadas para estandarizar.
//   → se obtienen con scaler.mean_ después de entrenar el StandardScaler.
const float wine_mean[NUM_FEATURES] = {
  8.30648944, 0.52807271, 0.27387803, 2.54358874, 0.08893432,
 16.12783425, 47.28068804, 0.99673525, 3.30858483, 0.66367475, 10.42444618
};

// wine_scale: desviaciones estándar de cada característica.
//   → se obtienen con scaler.scale_ (o scaler.var_**0.5) en Python.
const float wine_scale[NUM_FEATURES] = {
 1.69466258, 0.17764075, 0.19482589, 1.37515865, 0.05096132,
10.4694667, 33.3217514, 0.00185142, 0.15153976, 0.17829075, 1.06525516
};

// ===========================================================
// ====== Modelo de Clasificación (Regresión Logística) ======
// ===========================================================
// NUM_CLASSES: número de etiquetas de calidad presentes en el dataset.
//   → corresponde a len(model.classes_).
const byte NUM_CLASSES  = 7;

// wine_classes: valores reales de las clases de calidad (por ejemplo 3–9).
//   → se copian directamente de model.classes_.
const int wine_classes[NUM_CLASSES] = {3,4,5,6,7,8,9};

// wine_bias: interceptos o sesgos de la regresión logística.
//   → provienen de model.intercept_ (un valor por clase).
const float wine_bias[NUM_CLASSES] = {
  -2.2472930, -0.3489396,  2.3985654,
   3.1009241,  1.7729446, -0.1427767, -4.5334248
};

// wine_weights: matriz de coeficientes (pesos) del modelo.
//   → provienen de model.coef_ (dimensión [NUM_CLASSES x NUM_FEATURES]).
//   → cada fila corresponde a una clase en el mismo orden de wine_classes.
//   → cada columna corresponde a un feature en el orden original de X.columns.
const float wine_weights[NUM_CLASSES][NUM_FEATURES] = {
  { 0.5502053,  0.4488466, -0.1978983, -0.3656230,  0.1710165,  0.5250994,  0.0373662,  0.4452281,  0.0599720, -0.3500447, -0.1575677},
  {-0.1072066,  0.6514995, -0.1063810, -1.1783029,  0.2747752, -0.6757388, -0.0990405,  1.0127447, -0.2368382, -0.0454761, -0.6171157},
  {-0.4229265,  0.2957353,  0.0138553, -0.6439604,  0.1953725, -0.1111242,  0.1083033,  0.6957574, -0.4695233, -0.1033569, -0.8362290},
  {-0.4728328, -0.3134347,  0.0567800, -0.1575899,  0.1924977,  0.0166892,  0.0681109,  0.3757548, -0.3945216,  0.0645533,  0.1021029},
  {-0.0215237, -0.4655347, -0.0461446,  0.8754953, -0.1114183,  0.1288944,  0.0424428, -1.0573840,  0.0506697,  0.2393329,  0.1671436},
  {-0.1165212, -0.4714686,  0.0333069,  1.2411292,  0.0894870,  0.2896661, -0.0152714, -1.2471800,  0.1260486,  0.1595192,  0.5197812},
  { 0.5908053, -0.1456435,  0.2464817,  0.2288516, -0.8117306, -0.1734861, -0.1419113, -0.2249209,  0.8641927,  0.0354722,  0.8218849}
};




//Como configurarlo:
//Cantidad de atributos: Depende de la cantidad de atributos que contenga tu dataset
//const byte NUM_FEATURES = 11; 

//Escalador (mean y scale): Proporcionado por el código de entrenamiento, debes colocar los valores obtenidos en esta sección.
//const float wine_mean[NUM_FEATURES] = { … }; Debes colocar los valores obtenidos y separarlos por comas (,)
//const float wine_scale[NUM_FEATURES] = { … };

//Clases de salida: Cambiar la cantidad de clases distintas y sus etiquetas.
//const byte NUM_CLASSES  = 7;
//const int wine_classes[NUM_CLASSES] = {3,4,5,6,7,8,9};

//Parámetros del modelo (pesos y bias): Cambiar los coeficientes y sesgos que salgan del modelo que entrenes
//const float wine_bias[NUM_CLASSES] = { … }; Obtenidos del modelo_arduino.txt
//const float wine_weights[NUM_CLASSES][NUM_FEATURES] = { … };

